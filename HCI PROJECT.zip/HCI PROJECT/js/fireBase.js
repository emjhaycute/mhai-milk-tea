var app_fireBase = {};
(function(){
  var firebaseConfig = {
    apiKey: "AIzaSyCcvqBviS4UgglaiEGo2sFQL6NkijpFJ_c",
    authDomain: "loginform-8ea24.firebaseapp.com",
    projectId: "loginform-8ea24",
    storageBucket: "loginform-8ea24.appspot.com",
    messagingSenderId: "101388802304",
    appId: "1:101388802304:web:2f06113af25355c645bbe5"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  app_fireBase = firebase;
})()

